from engineering_notation import EngNumber as engr
import math
import matplotlib.pyplot as plt
import joby_m_anthony_iii.numerical_methods as nm
import numpy as np
import pandas as pd
import sympy as sp
from types import FunctionType

A0_1, B0_1, C0_1, D0_1 = (0, 1), (1, 1), (1, 0), (0, 0) # m
A1_1, B1_1, C1_1, D1_1 = (-0.003, 0.0025), (-0.005, 0.0035), (-0.002, 0.001), (0, 0) # m
theta_1 = np.radians(30) # rad
sym_c_1 = [sp.Symbol("c1"), sp.Symbol("c2"), sp.Symbol("c3"), sp.Symbol("c4")]
sym_d_1 = [sp.Symbol("d1"), sp.Symbol("d2"), sp.Symbol("d3"), sp.Symbol("d4")]
u_1 = lambda c, x, y: c[0] + c[1]*x + c[2]*y + c[3]*x*y
v_1 = lambda d, x, y: d[0] + d[1]*x + d[2]*y + d[3]*x*y
sym_xy_1 = sym_x_1, sym_y_1 = sp.Symbol("x"), sp.Symbol("y")
sym_u_1 = sp.expand(u_1(sym_c_1, *sym_xy_1))
sym_v_1 = sp.expand(v_1(sym_d_1, *sym_xy_1))

Auv_1 = np.array([\
    # at A
    [1, A0_1[0], A0_1[1], A0_1[0]*A0_1[1]], \
    # at B
    [1, B0_1[0], B0_1[1], B0_1[0]*B0_1[1]], \
    # at C
    [1, C0_1[0], C0_1[1], C0_1[0]*C0_1[1]], \
    # at D
    [1, D0_1[0], D0_1[1], D0_1[0]*D0_1[1]], \
])

bu_1 = np.array([A1_1[0], B1_1[0], C1_1[0], D1_1[0]]).reshape((len(Auv_1), 1))
x0u_1 = np.ones_like(bu_1)
c_1 = np.linalg.lstsq(Auv_1, bu_1)[0].reshape(1, len(x0u_1))[0]

bv_1 = np.array([A1_1[1], B1_1[1], C1_1[1], D1_1[1]]).reshape((len(Auv_1), 1))
x0v_1 = np.ones_like(bv_1)
d_1 = np.linalg.lstsq(Auv_1, bv_1)[0].reshape(1, len(x0v_1))[0]

# build string function from constants
f_1 = lambda sym_function, sym_variables, constants: sp.lambdify(sym_xy_1, sp.lambdify(sym_variables, sym_function)(*constants))
u_1 = lambda point: f_1(sym_u_1, (sym_c_1), c_1)(*point)
sym_u_1 = sp.expand(u_1(sym_xy_1))
v_1 = lambda point: f_1(sym_v_1, (sym_d_1), d_1)(*point)
sym_v_1 = sp.expand(v_1(sym_xy_1))

# determine form of derivative
df_1 = lambda sym_function, sym_variable, point: sp.lambdify(sym_xy_1, sp.diff(sym_function, sym_variable))(*point)
epsilon_1 = lambda point: np.array([\
    [df_1(sym_u_1, sym_x_1, point), df_1(sym_u_1, sym_y_1, point) + df_1(sym_v_1, sym_x_1, point)], \
    [df_1(sym_u_1, sym_y_1, point) + df_1(sym_v_1, sym_x_1, point), df_1(sym_v_1, sym_y_1, point)], \
])

epsA_1 = epsilon_1(A0_1)
epsB_1 = epsilon_1(B0_1)
epsC_1 = epsilon_1(C0_1)
epsD_1 = epsilon_1(D0_1)

eps_1a = epsA_1 # m/m
eps_nO1a = np.linalg.norm(np.diag(eps_1a))
eps_tO1a = np.linalg.norm(eps_1a) - eps_nO1a

s_1 = lambda p, dc: np.matmul(p, dc)
t_1 = lambda p, s: np.sqrt(p**2 - s**2)
# i_1b, j_1b = -4, -3
# ijk_1b = np.array([i_1b, j_1b])
# s_1b = s_1(eps_1a, ijk_1b)
# dem_1b = np.sqrt(np.sum(np.power(ijk_1b, 2)))
dc_1b = l_1b, m_1b = np.cos(theta_1), np.sin(theta_1) # ijk_1b/dem_1b
# s_1b = s_1(eps_1a, dc_1b)
s_1b = np.array([\
    [(eps_1a[0][0] + eps_1a[1][1])/2 + (eps_1a[0][0] + eps_1a[1][1])/2*np.cos(2*theta_1) + eps_1a[0][1]/2*np.sin(2*theta_1), -(eps_1a[0][0] - eps_1a[1][1])*np.sin(2*theta_1) + eps_1a[0][1]*np.cos(2*theta_1)], \
    [-(eps_1a[0][0] - eps_1a[1][1])*np.sin(2*(theta_1 + np.pi/2)) + eps_1a[0][1]*np.cos(2*(theta_1 + np.pi/2)), (eps_1a[0][0] + eps_1a[1][1])/2 + (eps_1a[0][0] + eps_1a[1][1])/2*np.cos(2*(theta_1 + np.pi/2)) + eps_1a[0][1]/2*np.sin(2*(theta_1 + np.pi/2))], \
])
t_1b = t_1(np.linalg.norm(s_1b), s_1b)