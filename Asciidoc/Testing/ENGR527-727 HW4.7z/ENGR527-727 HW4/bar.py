from engineering_notation import EngNumber as engr
import math
import matplotlib.pyplot as plt
import joby_m_anthony_iii.numerical_methods as nm
import numpy as np
import pandas as pd
import sympy as sp
from types import FunctionType

# --------------------
# eigenvalue solvers
class DirectSolver:
    def __init__(self, A, power, max_iter=100):
        """
        Parameters
        ----------
        A : tuple
            Characteristic matrix.

        power : int
            Signed power to which function error must be within.

        max_iter : int, optional
            Maximum iterations for which function may loop.

        Yields
        ------
        self.A : tuple
            Either input functions or matrix of characteristic values.

        self.tol : float
            Specified tolerance to which method terminates.

        self.max_iter : int
            Maximum iterations allowed for method.

        self.is_diagonal : bool
            Truth value of whether matrix is diagonal.

        self.eigenvalues : tuple
            Eigenvalues of characteristic matrix, A.

        self.spectral_radius : float
            Spectral radius of characteristic matrix, A.

        self.condition_number : float
            Condition number of characteristic matrix, A.

        Raises
        ------
        IndexError
            Matrix of interest must be square.

        ValueError
            If iterations constraint is not an integer.

        Warnings
        --------
        Not recommended to use eigen_values() to find eigenvalues of characteristic matrix, A; therefore, do not use eigen_values() if matrix, A is a large, sparse matrix if desiring quick calculations.

        See Also
        --------
        eigen_values() : Function to find eigenvalues of A.

        spectral_radius() : Function that finds the spectral radius of characteristic matrix, A.

        Notes
        -----
        Specified tolerance evaluated by `10**power`.

        `norm_type` may be either `'l_infinity'` or `'l_two'` but is 'l_infinity' by default.

        If `self.is_diagonal` is True, then matrix is diagonal. Else, not diagonal.
        """
        matrix_name, A = "A", np.array(A)
        if np.sum(A.shape[0]) != np.sum(A.shape[1]): raise IndexError(f"ERROR! Matrix, {matrix_name} must be square!")
        if max_iter <= 0 or not isinstance(max_iter, (int, float)): raise ValueError(f"ERROR! Maximum iterations, N must be an integer greater than zero. {max_iter} was given and not understood.")
        self.A = A
        self.tol = float(10**power)
        self.max_iter = int(max_iter)
        self.is_diagonal = nm.diagonality(A)
        self.is_tridiagonal = nm.tridiagonality(A)

    def steepest_descent(self, x, b):
        """Approximate solution vector, x given matrix, A initial guess vector, x, and vector, b.

        Parameters
        ----------
        x : array
            Numpy array.

        b : array
            Input numpy array.

        Returns
        -------
        pandas.DataFrame : dataframe
            Summarized dataframe from iterations.

        Yields
        ------
        self.x : tuple
            Initial guess at eigenvector.

        self.b : tuple
            Input numpy array.

        self.iterations : tuple
            Collection of iterations through method.

        self.lambdas : tuple
            Collection of approximate eigenvectors.

        self.errors : tuple
            Collection of yielded norms.

        Raises
        ------
        IndexError
            If x is neither n x 1 nor 1 x n array.

        IndexError
            If b is neither n x 1 nor 1 x n array.
        """
        A, tol, N = self.A, self.tol, self.max_iter
        vec_name, x = "x", np.array(x)
        if np.sum(x.shape) - np.sum(x.shape[0]) > 1: raise IndexError(f"Systems vector, {vec_name} must be n x 1 or 1 x n array!")
        self.x = np.reshape(x,(len(x),1))
        vec_name, b = "b", np.array(b)
        if np.sum(b.shape) - np.sum(b.shape[0]) > 1: raise IndexError(f"Systems vector, {vec_name} must be n x 1 or 1 x n array!")
        self.b = np.reshape(b,(len(b),1))
        k, eigenvectors, errors = 1, [x.reshape(1, len(x))], [1]
        while errors[-1] > tol and k <= N:
            r = b - np.matmul(A, x)
            alpha = float(np.matmul(r.T, r)[0]/np.matmul(np.matmul(r.T, A), r)[0])
            x1 = x + alpha*r
            eigenvectors.append(x1.reshape(1, len(x1))[0])
            errors.append(nm.norms(x1, x).l_infinity())
            x = x1
            k += 1
        self.iterations = np.array(range(k))
        self.lambdas = np.array(eigenvectors, dtype=object)
        self.errors = np.array(errors)
        return pd.DataFrame(data={"Iterations": self.iterations, "Lambdas": self.lambdas, "Errors": self.errors})

    def conjugate_gradient(self, x, b, C=None):
        """Approximate solution vector given matrix, A, initial guess vector, x, and vector, b.

        Parameters
        ----------
        x : array
            Numpy array.

        b : vector
            Input numpy array.

        C : None or matrix, optional
            Preconditioning matrix.

        Returns
        -------
        pandas.DataFrame : dataframe
            Summarized dataframe from iterations.

        Yields
        ------
        self.x : tuple
            Initial guess at eigenvector.

        self.b : tuple
            Input numpy array.

        self.iterations : tuple
            Collection of iterations through method.

        self.lambdas : tuple
            Collection of approximate eigenvectors.

        self.errors : tuple
            Collection of yielded norms.

        Raises
        ------
        IndexError
            If x is neither n x 1 nor 1 x n array.

        IndexError
            If b is neither n x 1 nor 1 x n array.
        """
        A, tol, N = self.A, self.tol, self.max_iter
        vec_name, x = "x", np.array(x)
        if np.sum(x.shape) - np.sum(x.shape[0]) > 1: raise IndexError(f"Systems vector, {vec_name} must be n x 1 or 1 x n array!")
        self.x = np.reshape(x,(len(x),1))
        vec_name, b = "b", np.array(b)
        if np.sum(b.shape) - np.sum(b.shape[0]) > 1: raise IndexError(f"Systems vector, {vec_name} must be n x 1 or 1 x n array!")
        self.b = np.reshape(b,(len(b),1))
        x, b, self.C = self.x, self.b, C
        r0 = b - np.matmul(A, x)
        if type(C) == type(None):
            do_precondition = True
            v0 = r0
        else:
            do_precondition = False
            Minv = np.linalg.inv(C*np.transpose(C))
            v0 = np.matmul(Minv, r0)
        k, eigenvectors, errors = 1, [x.reshape(1, len(x))], [1]
        while errors[-1] > tol and k <= N:
            if do_precondition:
                alpha = float(np.matmul(r0.T, r0)[0]/np.matmul(np.matmul(v0.T, A)[0], v0)[0])
            else:
                alpha = float(np.matmul(np.matmul(r0.T, Minv), r0)[0]/np.matmul(np.matmul(v0.T, A), v0)[0])
            x1 = x + alpha*v0
            eigenvectors.append(x1.reshape(1, len(x1))[0])
            errors.append(nm.norms(x1, x).l_infinity())
            r1 = r0 - alpha*np.matmul(A, v0)
            if do_precondition:
                s1 = float(np.matmul(r1.T, r1)[0]/np.matmul(r0.T, r0)[0])
            else: s1 = float(np.matmul(np.matmul(r1.T, Minv)[0], r1)[0]/np.matmul(np.matmul(r0.T, Minv)[0], r0)[0])
            x, r0 = x1, r1
            if do_precondition: v0 = r1 + s1*v0
            else: v0 = np.matmul(Minv, r1) + s1*v0
            k += 1
        self.iterations = np.array(range(k))
        self.lambdas = np.array(eigenvectors, dtype=object)
        self.errors = np.array(errors)
        return pd.DataFrame(data={"Iterations": self.iterations, "Lambdas": self.lambdas, "Errors": self.errors})
# --------------------

# --------------------
# iterative techniques
class SingleVariableIteration:
    def __init__(self, function, a, b, power=-6, variable=sp.Symbol("x"), iter_guess=True, k=0):
        """
        Parameters
        ----------
        function : expression
            Input function.

        a : float
            Left-hand bound of interval.

        b : float
            Right-hand bound of interval.

        power : float, optional
            Signed, specified power of tolerance until satisfying method.

        variable : symbol, optional
            Respected variable in derivative. Assumed to be 'x' if not stated.

        iter_guess : bool or integer, optional
            Boolean value of `True` by default. If integer, iterate for that integer.

        k : float, optional
            Absolute maximum slope of function.

        Yields
        ------
        self.function : expression
            Input function.

        self.a : float
            Left-hand bound of interval.

        self.b : float
            Right-hand bound of interval.

        self.tol : float
            Tolerance to satisfy method.

        self.variable : symbol, optional
            Respected variable in derivative. Assumed to be `'x'` if not stated.

        self.iter_guess : bool or integer, optional
            Boolean value of `True` by default. If integer, iterate for that integer.

        self.k : float, optional
            Absolute maximum slope of functon. Assumed 0 if not defined.

        Raises
        ------
        TypeError
            If input expression cannot be understood as lambda or sympy expression nor as string.

        Notes
        -----
        self.tol evaluated by: `10**power`.
        """
        if isinstance(function, (FunctionType, sp.Expr)):
            sym_function = sp.N(sp.sympify(function(variable)))
            function = sp.lambdify(variable, sym_function)
            print(f"Information: Input expression, {sym_function} used.")
        # elif isinstance(f, (sp.Expr)):
        # 	f = sp.lambdify(variable, f)
        # 	self.function = f
        # 	print("sympy expression converted to lambda function.")
        elif isinstance(function, (str)):
            g = lambda x: eval(function)
            function = sp.lambdify(variable, g(variable))
            print("String expression converted to lambda function.")
        else: raise TypeError("Unknown input.")
        self.function, self.variable = function, variable
        self.a, self.b, self.tol = float(a), float(b), float(10**power)
        self.iter_guess, self.k = iter_guess, k

    def find_k(self):
        """Find greatest integer for maximum iterations for tolerance.

        Returns
        -------
        k : float
            Maximum possible slope of input function.

        Yields
        ------
        self.k : float
            Maximum possible slope of input function.

        Warnings
        --------
        Prints to console the input expression, and that the expression was in fact used.
        """
        a, b, variable = self.a, self.b, self.variable
        # sp.expand()
        sym_function = sp.N(sp.sympify(self.function(variable)))
        function = sp.lambdify(variable, sym_function)
        print(f"Information: Input expression, {sym_function} used.")
        k = self.k
        # determine form of derivative
        df = sp.lambdify(variable, sp.diff(sym_function))
        for alpha in np.linspace(a, b, 1000):
            df_alpha = abs(df(alpha))
            if df_alpha > k: k = df_alpha
        self.k = k
        return k

    def max_iterations(self, method, p0=0):
        """Find greatest integer for maximum iterations for tolerance.

        Parameters
        ----------
        method : string
            Selection of iterative method for iterations are needed.

        p0 : float, optional
            Initial guess for function solution.

        Returns
        -------
        max_iter : integer
            Maximum number of iterations required for specified tolerance.

        Yields
        ------
        self.max_iter : integer
            Maximum number of iterations required for specified tolerance.

        Raises
        ------
        ValueError
            Prescribed method is not an available option.

        Warnings
        --------
        Informs user the maximum number of iterations for method.

        Notes
        -----
        Will round away from zero to higher integers.

        Examples
        --------
        If `method == 'bisection'` & a=1, b=2, and tol=-3, then:

        `max_iter` >= -log(`tol`/(`b` - `a`))/log(2)

        `max_iter` >= -log((10**(-3)/(2 - 1))/log(2)

        `max_iter` >= 9.96

        `max_iter` = 10

        Else, if a=1, b=2, tol=-3, p0=1.5, nd k=0.9, then:
        `max_iter` >= log(`tol`/max('p0' - `a`, `b` - `p0`))/log(k)

        `max_iter` >= log(10**(-3)/max(1.5 - 1, 2 - 1.5))/log(0.9)

        `max_iter` >= log(10**(-3)/0.5)/log(0.9)

        `max_iter` >= 58.98

        `max_iter` >= 59
        """
        a, b, tol, k = self.a, self.b, self.tol, self.k
        p0 = float(p0)
        if method == "bisection":
            max_iter = math.ceil(-math.log(tol/(b - a))/math.log(2))
        elif method in ("fixed_point", "newton_raphson", "secant_method", "false_position"):
            max_iter = math.ceil(-math.log(tol/max(p0 - a, b - p0))/math.log(k))
        else: raise ValueError(f"ERROR! I am sorry. The desired method must be: 'bisection', 'fixed_point', 'newton_raphson', 'secant_method', or 'false_position'.")
        self.max_iter = max_iter
        print(f"Information: With the inputs, I will terminate the technique after so many iterations, N = {max_iter}")
        return max_iter

    # next 5 functions preceded by find_k & max_iterations

    def bisection(self):
        """Given f(x) in [a, b] find x within tolerance. Is a root-finding method: f(x) = 0.

        Returns
        -------
        pandas.DataFrame : dataframe
            Summarized dataframe from iterations.

        Yields
        ------
        self.iterations : tuple
            Collection of iterations through method.

        self.approximations : tuple
            Collection of evaluated points, p.

        self.errors : tuple
            Collection of propogated error through method.

        Raises
        ------
        ValueError
            If input for desired iterations was assigned not an integer.

        ValueError
            If initial guesses did not evaluate to have opposite signs.

        TypeError
            If input expression cannot be understood as lambda or sympy expression nor as string.

        Warnings
        --------
        Print to console if solution was found, or state that solution did not converge with given guess or prescribed tolerance.

        Notes
        -----
        Relying on the Intermediate Value Theorem, this is a bracketed, root-finding method. Generates a sequence {p_n}^{inf}_{n=1} to approximate a zero of f(x), p and converges by O(1 / (2**N)).

        Examples
        --------
        If  f(x) = x**3 + 4*x**2 = 10

        =>  f(x) = x**3 + 4*x**2 - 10 = 0
        """
        f, a, b, tol = self.function, self.a, self.b, self.tol
        iter_guess = self.iter_guess
        # calculate if expression
        if isinstance(f, (FunctionType, sp.Expr)):
            sym_function = sp.N(sp.sympify(f(self.variable)))
            f = sp.lambdify(self.variable, sym_function)
            # check if f(a) and f(b) are opposite signs
            if f(a)*f(b) < 0:
                if iter_guess == True:
                    # if left unassigned, guess
                    N = self.max_iterations("bisection")
                elif isinstance(iter_guess, (int, float)):
                    # if defined as integer, use
                    N = int(iter_guess)
                # else, break for bad assignment
                else: raise ValueError(f"ERROR! Maximum iterations, N must be an integer greater than zero. {iter_guess} was given and not understood.")
                # initialize
                k, approximations, errors = 0, [f(a)], [1]
                # exit by whichever condition is TRUE first
                while errors[-1] >= tol and k <= N:
                    x = (b - a)/2
                    p = a + x 	# new value, p
                    approximations.append(p)
                    if f(a)*f(p) > 0: a = p 	# adjust next bounds
                    else: b = p
                    errors.append(abs(x)) 	# error of new value, p
                    k += 1 	# iterate to k + 1
                if k <= N: print("Congratulations! Solution found!")
                else: print("Warning! Solution could not be found with initial guess or tolerance.")
                self.iterations = np.array(range(k))
                self.approximations = np.array(approximations)
                self.errors = np.array(errors)
                return pd.DataFrame(data={"Iterations": self.iterations, "Approximations": self.approximations, "Errors": self.errors})
            # abort if f(a) is not opposite f(b)
            else: raise ValueError(f"ERROR! Interval bounds, [a, b] = [{a}, {b}] must yield opposite signs in function, {sym_function}.")
        # abort if not expression
        else: raise TypeError("ERROR! The input function must be an expression.")

    def false_position(self, p0, p1):
        """Given f(x) and initial guesses, p0 and p1 in [a, b] find x within tolerance.

        Root-finding problem: f(x) = 0. 

        !!! Use lowest k !!!

        Parameters
        ----------
        p0 : float
            First initial guess.

        p1 : float
            Second initial guess.

        Returns
        -------
        pandas.DataFrame : dataframe
            Summarized dataframe from iterations.

        Yields
        ------
        self.iterations : tuple
            Collection of iterations through method.

        self.approximations : tuple
            Collection of evaluated points, p.

        self.errors : tuple
            Collection of propogated error through method.

        Raises
        ------
        ValueError
            If input for desired iterations was assigned not an integer.

        ValueError
            If initial guesses did not evaluate to have opposite signs.

        TypeError
            If input expression cannot be understood as lambda or sympy expression nor as string.

        Warnings
        --------
        Print to console if solution was found, or state that solution did not converge with given guess or prescribed tolerance.

        Notes
        -----
        Check that |g'(x)| <= (leading coefficient of g'(x)) for all x in [a, b].

        Theorem:
        1) Existence of a fixed-point:
            If g in C[a,b] and g(x) in C[a, b] for all x in [a, b], then function, g has a fixed point in [a, b].

        2) Uniqueness of a fixed point:
            If g'(x) exists on [a, b] and a positive constant, k < 1 exist with {|g'(x)| <= k  |  x in (a, b)}, then there is exactly one fixed-point, p in [a, b].

        Converges by O(linear) if g'(p) != 0, and O(quadratic) if g'(p) = 0 and g''(p) < M, where M = g''(xi) that is the error function.

        Examples 
        --------
        If  g(x) = x**2 - 2

        Then	p = g(p) = p**2 - 2

        =>  p**2 - p - 2 = 0
        """
        f, a, b, tol = self.function, self.a, self.b, self.tol
        iter_guess, k = self.iter_guess, self.k
        p0, p1 = float(p0), float(p1)
        self.p0, self.p1 = p0, p1
        # calculate if expression
        if isinstance(f, (FunctionType, sp.Expr)):
            sym_function = sp.N(sp.sympify(f(self.variable)))
            f = sp.lambdify(self.variable, sym_function)
            # check if f(a) and f(b) are opposites signs
            if f(p0)*f(p1) < 0:
                if iter_guess == True and k == 0:
                    # if left unassigned, guess
                    N = self.max_iterations("false position", p0=p0)
                elif iter_guess == True and k != 0:
                    # if left unassigned, guess
                    N = self.max_iterations("false position", k=k, p0=p0)
                elif isinstance(iter_guess, (int, float)):
                    # if defined as integer, use
                    N = int(iter_guess)
                # else, break for bad assignment
                else: raise ValueError(f"ERROR! Maximum iterations, N must be an integer greater than zero. {iter_guess} was given and not understood.")
                # initialize
                k, approximations, errors = 0, [f(a)], [1]
                # exit by whichever condition is TRUE first
                while errors[-1] >= tol and k <= N:
                    q0, q1 = f(p0), f(p1)
                    p = p1 - q1*(p1 - p0)/(q1 - q0) 	# new value, p
                    approximations.append(p)
                    errors.append(abs(p - p0)) 	# error of new value, p
                    if f(p)*q1 < 0: p0 = p1 	# adjust next bounds
                    p1 = p
                    k += 1 	# iterate to k + 1
                if k <= N: print("Congratulations! Solution found!")
                else: print("Warning! Solution could not be found with initial guess or tolerance.")
                self.iterations = np.array(range(k))
                self.approximations = np.array(approximations)
                self.errors = np.array(errors)
                return pd.DataFrame(data={"Iterations": self.iterations, "Approximations": self.approximations, "Errors": self.errors})
            # abort if f(a) is not opposite f(b)
            else: raise ValueError(f"ERROR! Interval bounds, [a, b] = [{a}, {b}] must yield opposite signs in function, {sym_function}.")
        # abort if not expression
        else: raise TypeError("ERROR! The input function must be an expression.")

    def fixed_point(self, p0):
        """Given f(x) and initial guess, p0 in [a, b] find x within tolerance.

        Root-finding problem: f(x) = 0. 

        !!! Use lowest k !!!

        Parameters
        ----------
        p0 : float
            Initial guess.

        Returns
        -------
        pandas.DataFrame : dataframe
            Summarized dataframe from iterations.

        Yields
        ------
        self.iterations : tuple
            Collection of iterations through method.

        self.approximations : tuple
            Collection of evaluated points, p.

        self.errors : tuple
            Collection of propogated error through method.

        Raises
        ------
        ValueError
            If input for desired iterations was assigned not an integer.

        ValueError
            If initial guesses did not evaluate to have opposite signs.

        TypeError
            If input expression cannot be understood as lambda or sympy expression nor as string.

        Warnings
        --------
        Print to console if solution was found, or state that solution did not converge with given guess or prescribed tolerance.

        Notes
        -----
        Check that |g'(x)| <= (leading coefficient of g'(x)) for all x in [a, b].

        Theorem:
        1) Existence of a fixed-point:
            If g in C[a, b] and g(x) in C[a, b] for all x in [a, b], then function, g has a fixed point in [a, b].

        2) Uniqueness of a fixed point:
            If g'(x) exists on [a, b] and a positive constant, k < 1 exist with {|g'(x)| <= k  |  x in (a, b)}, then there is exactly one fixed-point, `p` in [a, b].

        Converges by O(linear) if g'(p) != 0, and O(quadratic) if g'(p) = 0 and g''(p) < M, where M = g''(xi) that is the error function.

        Examples 
        --------
        If  g(x) = x**2 - 2

        Then	p = g(p) = p**2 - 2
        
        =>  p**2 - p - 2 = 0
        """
        f, a, b, tol = self.function, self.a, self.b, self.tol
        iter_guess, k = self.iter_guess, self.k
        p0 = float(p0)
        self.p0 = p0
        # calculate if expression
        if isinstance(f, (FunctionType, sp.Expr)):
            sym_function = sp.N(sp.sympify(f(self.variable)))
            f = sp.lambdify(self.variable, sym_function)
            if iter_guess == True and k == 0:
                # if left unassigned, guess
                N = self.max_iterations("fixed point", p0=p0)
            elif iter_guess == True and k != 0:
                # if left unassigned, guess
                N = self.max_iterations("fixed point", k=k, p0=p0)
            elif isinstance(iter_guess, (int, float)):
                # if defined as integer, use
                N = int(iter_guess)
            # else, break for bad assignment
            else: raise ValueError(f"ERROR! Maximum iterations, N must be an integer greater than zero. {iter_guess} was given and not understood.")
            # initialize
            k, approximations, errors = 0, [f(a)], [1]
            # exit by whichever condition is TRUE first
            while errors[-1] >= tol and k <= N:
                p = f(p0) 	# new value, p
                approximations.append(p)
                errors.append(abs((p - p0)/p0)) # error of new value, p
                p0 = p 	# set future previous value
                k += 1 	# iterate to k + 1
            if k <= N: print("Congratulations! Solution found!")
            else: print("Warning! Solution could not be found with initial guess or tolerance.")
            self.iterations = np.array(range(k))
            self.approximations = np.array(approximations)
            self.errors = np.array(errors)
            return pd.DataFrame(data={"Iterations": self.iterations, "Approximations": self.approximations, "Errors": self.errors})
        # abort if not expression
        else: raise TypeError("ERROR! The input function must be an expression.")

    def newton_raphson(self, p0):
        """Given f(x) and initial guess, p0 in [a, b], find x within tolerance.

        Root-finding problem: f(x) = 0. 

        !!! Use lowest k !!!

        Parameters
        ----------
        p0 : float
            Initial guess.

        Returns
        -------
        pandas.DataFrame : dataframe
            Summarized dataframe from iterations.

        Yields
        ------
        self.iterations : tuple
            Collection of iterations through method.

        self.approximations : tuple
            Collection of evaluated points, p.

        self.errors : tuple
            Collection of propogated error through method.

        Raises
        ------
        ValueError
            If input for desired iterations was assigned not an integer.

        ValueError
            If initial guesses did not evaluate to have opposite signs.

        TypeError
            If input expression cannot be understood as lambda or sympy expression nor as string.

        Warnings
        --------
        Print to console if solution was found, or state that solution did not converge with given guess or prescribed tolerance.

        Notes
        -----
        f'(x) != 0.

        Not root-bracketed.

        Initial guess must be close to real solution; else, will converge to different root or oscillate (if symmetric).

        Check that |g'(x)| <= (leading coefficient of g'(x)) for all x in [a, b].

        Technique based on first Taylor polynomial expansion of f about p0 and evaluated at x = p. |p - p0| is assumed small; therefore, 2nd order Taylor term, the error, is small.

        Newton-Raphson has quickest convergence rate.

        This method can be viewed as fixed-point iteration.

        Theorem:
        1) Existence of a fixed-point:
            If g in C[a, b] and g(x) in C[a, b] for all x in [a, b], then function, g has a fixed point in [a, b].

        2) Uniqueness of a fixed point:
            If g'(x) exists on [a, b] and a positive constant, `k` < 1 exist with {|g'(x)| <= k  |  x in (a, b)}, then there is exactly one fixed-point, `p` in [a, b].

        Converges by O(linear) if g'(p) != 0, and O(quadratic) if g'(p) = 0 and g''(p) < M, where M = g''(xi) that is the error function.

        Examples 
        --------
        If  g(x) = x**2 - 2

        Then	p = g(p) = p**2 - 2

        =>  p**2 - p - 2 = 0
        """
        f, a, b, tol = self.function, self.a, self.b, self.tol
        iter_guess, k = self.iter_guess, self.k
        p0 = float(p0)
        self.p0 = p0
        # calculate if expression
        if isinstance(f,(FunctionType, sp.Expr)):
            sym_function = sp.N(sp.sympify(f(self.variable)))
            f = sp.lambdify(self.variable, sym_function)
            # determine form of derivative
            df = sp.lambdify(self.variable, sp.diff(sym_function))
            if iter_guess == True and k == 0:
                # if left unassigned, guess
                N = self.max_iterations("newton raphson", p0=p0)
            elif iter_guess == True and k != 0:
                # if left unassigned, guess
                N = self.max_iterations("newton raphson", k=k, p0=p0)
            elif isinstance(iter_guess, int):
                # if defined as integer, use
                N = iter_guess
            # else, break for bad assignment
            else: raise ValueError(f"ERROR! Maximum iterations, N must be an integer greater than zero. {iter_guess} was given and not understood.")
            # initialize
            k, approximations, errors = 0, [f(a)], [1]
            # exit by whichever condition is TRUE first
            while errors[-1] >= tol and k <= N:
                fp0 = f(p0)
                dfp0 = df(p0)
                p = p0 - (fp0/dfp0)	 # new value, p
                approximations.append(p)
                errors.append(abs(p - p0)) 	# error of new value, p
                p0 = p 	# set future previous value
                k += 1 	# iterate to k + 1
            if k <= N: print("Congratulations! Solution found!")
            else: print("Warning! Solution could not be found with initial guess or tolerance.")
            self.iterations = np.array(range(k+1))
            self.approximations = np.array(approximations)
            self.errors = np.array(errors)
            return pd.DataFrame(data={"Iterations": self.iterations, "Approximations": self.approximations, "Errors": self.errors})
        # abort if not expression
        else: raise TypeError("ERROR! The input function must be an expression.")

    def secant_method(self, p0, p1):
        """Given f(x) and initial guesses, p0 and p1 in [a, b], find x within tolerance.
        Root-finding problem: f(x) = 0. 

        !!! Use lowest k !!!

        Parameters
        ----------
        p0 : float
            First initial guess.

        p1 : float
            Second initial guess.

        Returns
        -------
        pandas.DataFrame : dataframe
            Summarized dataframe from iterations.

        Yields
        ------
        self.iterations : tuple
            Collection of iterations through method.

        self.approximations : tuple
            Collection of evaluated points, p.

        self.errors : tuple
            Collection of propogated error through method.

        Raises
        ------
        ValueError
            If input for desired iterations was assigned not an integer.

        ValueError
            If initial guesses did not evaluate to have opposite signs.

        TypeError
            If input expression cannot be understood as lambda or sympy expression nor as string.

        Warnings
        --------
        Print to console if solution was found, or state that solution did not converge with given guess or prescribed tolerance.

        Notes
        -----
        Not root-bracketed.

        Bypasses need to calculate derivative (as in Newton-Raphson).

        Check that |g'(x)| <= (leading coefficient of g'(x)) for all x in [a, b].

        Theorem:
        1) Existence of a fixed-point:
            If g in C[a, b] and g(x) in C[a, b] for all x in [a, b], then function, g has a fixed point in [a, b].

        2) Uniqueness of a fixed point:
            If g'(x) exists on [a, b] and a positive constant, `k` < 1 exist with {|g'(x)| <= k  |  x in (a, b)}, then there is exactly one fixed-point, `p` in [a, b].

        Converges by O(linear) if g'(p) != 0, and O(quadratic) if g'(p) = 0 and g''(p) < M, where M = g''(xi) that is the error function.

        Examples 
        --------
        If  g(x) = x**2 - 2

        Then	p = g(p) = p**2 - 2

        =>  p**2 - p - 2 = 0
        """
        f, a, b, tol = self.function, self.a, self.b, self.tol
        iter_guess, k = self.iter_guess, self.k
        p0, p1 = float(p0), float(p1)
        self.p0, self.p1 = p0, p1
        # calculate if expression
        if isinstance(f, (FunctionType, sp.Expr)):
            sym_function = sp.N(sp.sympify(f(self.variable)))
            f = sp.lambdify(self.variable, sym_function)
            # check if f(a) and f(b) are opposite signs
            if f(p0)*f(p1) < 0:
                if iter_guess == True and k == 0:
                    # if left unassigned, guess
                    N = self.max_iterations("secant method", p0=p0)
                elif iter_guess == True and k != 0:
                    # if left unassigned, guess
                    N = self.max_iterations("secant method", k=k, p0=p0)
                elif isinstance(iter_guess, (int, float)):
                    # if defined as integer, use
                    N = (iter_guess)
                # else, break for bad assignment
                else: raise ValueError(f"ERROR! Maximum iterations, N must be an integer greater than zero. {iter_guess} was given and not understood.")
                # initialize
                k, approximations, errors = 0, [f(a)], [1]
                # exit by whichever condition is TRUE first
                while errors[-1] >= tol and k <= N:
                    q0, q1 = f(p0), f(p1)
                    # new value, p
                    p = p1 - q1*(p1 - p0)/(q1 - q0)
                    approximations.append(p)
                    errors.append(abs(p - p0)) 	# error of new value
                    p0, p1 = p1, p 	# set future previous values
                    k += 1 	# iterate to k + 1
                if k <= N: print("Congratulations! Solution found!")
                else: print("Warning! Solution could not be found with initial guess or tolerance.")
                self.iterations = np.array(range(k))
                self.approximations = np.array(approximations)
                self.errors = np.array(errors)
                return pd.DataFrame(data={"Iterations": self.iterations, "Approximations": self.approximations, "Errors": self.errors})
            # abort if f(a) is not opposite f(b)
            else: raise ValueError(f"ERROR! Interval bounds, [a, b] = [{a}, {b}] must yield opposite signs in function, {sym_function}.")
        # abort if not expression
        else: raise TypeError("ERROR! The input function must be an expression.")

class MultiVariableIteration:
    def __init__(self, A, x0, b, power=-6, max_iter=100, norm_type="l_infinity"):
        """
        Parameters
        ----------
        A : tuple
            Either input functions or matrix of characteristic values.

        x0 : tuple
            Either collection of symbols or initial guesses for system of equations.

        b : tuple
            Input vector.

        power : float, optional
            Signed, specified power of tolerance until satisfying method.

        max_iter : integer, optional
            Number of iterations.

        norm_type : string, optional
            String representation of desired norm function. `'l_infinity'` by default.

        Yields
        ------
        self.A : tuple
            Either input functions or matrix of characteristic values.

        self.x0 : tuple
            Either collection of symbols or initial guesses for system of equations.

        self.b : tuple
            Input vector.

        self.tol : float
            Specified tolerance to which method terminates.

        self.max_iter : int
            Maximum iterations allowed for method.

        self.norm_type : string
            String representation of desired norm function.

        self.is_diagonal : bool
            Truth value of whether matrix is diagonal.

        self.is_symmetric : bool
            Truth value of whether matrix is symmetric.

        self.is_tridiagonal : bool
            Truth value of whether matrix is tridiagonal.

        self.eigen_values : tuple
            Eigenvalues of characteristic matrix, A.

        self.spectral_radius : float
            Spectral radius of characteristic matrix, A.

        self.condition_number : float
            Condition number of characteristic matrix, A. 

        Raises
        ------
        IndexError
            Matrix of interest must be square.

        IndexError
            If x0 is neither n x 1 nor 1 x n array.

        IndexError
            If b is neither n x 1 nor 1 x n array.

        ValueError
            If iterations constraint is not an integer.

        ValueError
            If desired norm method was neither `'l_infinity'` nor `'l_two'`.

        Warnings
        --------
        Not recommended to use eigen_values() to find eigenvalues of characteristic matrix, A; therefore, if desiring quick calculations, do not use if matrix, A is a large, sparse matrix.

        See Also
        --------
        eigen_values() : Function to find eigenvalues of matrix, A.

        spectral_radius() : Function to find the spectral radius of characteristic matrix, A.

        Notes
        -----
        Specified tolerance evaluated by: `10**power`.

        norm_type may be either `'l_infinity'` or `'l_two'`. Is 'l_infinity' by default.

        If `self.is_diagonal` is True, then matrix is diagonal. Else, not diagonal.
        """
        matrix_name, vec_name, sys_name = "A", "x0", "b"
        A, x0, b = np.array(A), np.array(x0), np.array(b)
        if np.sum(A.shape[0]) != np.sum(A.shape[1]): raise IndexError(f"ERROR! Matrix, {matrix_name} must be square!")
        if np.sum(x0.shape) - np.sum(x0.shape[0]) > 1: raise IndexError(f"Systems vector, {vec_name} must be n x 1 or 1 x n array!")
        if np.sum(b.shape) - np.sum(b.shape[0])> 1: raise IndexError(f"Systems vector, {sys_name} must be n x 1 or 1 x n array!")
        if max_iter <= 0 or not isinstance(max_iter, (int, float)): ValueError(f"ERROR! Maximum iterations, N must be an integer greater than zero. {max_iter} was given and not understood.")
        if norm_type != "l_infinity" and norm_type != "l_two": raise ValueError("ERROR! Desired norm type was not understood. Please choose 'l_infinity' or 'l_two'.")
        n = len(x0)
        self.A = A
        self.x0 = np.reshape(x0,(n,1))
        self.b = np.reshape(b,(n,1))
        self.tol = float(10**power)
        self.max_iter = int(max_iter)
        self.norm_type = norm_type
        self.is_diagonal = nm.diagonality(A)
        self.is_symmetric = nm.symmetry(A)
        self.is_tridiagonal = nm.tridiagonality(A)
        # self.eigen_values = eigen_values(A)
        # self.spectral_radius = spectral_radius(A)
        # self.condition_number = condition_number(A, norm_type)

    def __find_xk(self, x):
        return np.matmul(self.T, x) + self.c

    def find_omega(self, omega=0):
        """Given the characteristic matrix and solution vector, determine if prescribed omega is the optimum choice.

        Parameters
        ----------
        omega : float, optional
            Relaxation parameter.

        Returns
        -------
        omega : float
            If found, is the optimum choice of omega.

        Yields
        ------
        self.user_omega : float
            Supplied/default omega.

        self.is_tridiagonal : bool
            Truth value of whether matrix, A is tridiagonal.

        self.best_omega : float
            If found, is the optimum choice of omega.

        Warnings
        --------
        If 0 < omega < 2, then method will converge regardless of choice for x0. Will inform user that matrix, A is not tridiagonal, but will proceed with calculation all the same. If matrix, A is poorly defined and not found to be positive definite, then user is informed but calculation proceeds. If an optimal omega cannot be found, then `self.best_omega` assigned from supplied/default omega.

        See Also
        --------
        tridiagonality() : Determines if matrix, A is tridiagonal or not.

        spectral_radius() : Uses the spectral radius of Gauss-Seidel's T-matrix to calculate omega.

        Notes
        -----
        Unless specified, omega will be 0 and chosen, if possible.
        """
        matrix_name = "A"
        A, x0, omega = np.array(self.A), np.array(self.x0), float(omega)
        self.user_omega = omega
        xn = sp.Matrix(np.reshape(np.zeros_like(x0), (len(x0), 1)))
        xt = sp.Matrix(np.reshape(np.zeros_like(x0), (1, len(x0))))
        i = 0
        for x in np.array(x0): xn[i], xt[i] = x, x; i += 1
        y = xt*sp.Matrix(A)*xn
        if y[0] > 0: state = True
        else: state = False
        if self.is_symmetric and state: theorem_6_22 = True
        else: theorem_6_22 = False
        i, theorem_6_25 = 1, True
        while i <= len(A) and theorem_6_25 == True:
            Ai = sp.Matrix(A[:i,:i])
            if sp.det(Ai) > 0: theorem_6_25 = True
            else : theorem_6_25 = False
            i += 1
        if theorem_6_22 or theorem_6_25:
            if 0 < omega and omega < 2: print("According to Ostrowski-Reich's Theorem, the successive relaxation technique will converge.")
            if self.is_tridiagonal:
                D = np.diagflat(np.diag(A))
                L = np.diagflat(np.diag(A, k=-1), k=-1)
                U = np.diagflat(np.diag(A, k=1), k=1)
                DL = D - L
                i, DL_inv = 0, np.zeros_like(DL)
                while i < len(DL_inv):
                    j = 0
                    while j < len(DL_inv[0]):
                        dl = DL[i][j]
                        if dl != 0: DL_inv[i][j] = 1/(dl)
                        j += 1
                    i += 1
                Tg = DL_inv*U
                omega = 2 / (1 + math.sqrt(1 - nm.spectral_radius(Tg)))
                print(f"I believe {omega} would be the best choice.")
            else:
                print(f"Warning! Matrix, {matrix_name} is not tridiagonal.")
                print(f"Assigning supplied omega, {omega} as `self.best_omega`.")
        else:
            print(f"Warning! Matrix, {matrix_name} is not positive definite.")
            print(f"Assigning supplied omega, {omega} as `self.best_omega`.")
        self.best_omega = omega
        return omega

    def gauss_seidel(self):
        """Given A*x = b, use `self.norm_type` to find x via the Gauss-Seidel Method.

        Returns
        -------
        pandas.DataFrame : dataframe
            Summarized dataframe from iterations.

        Yields
        -------
        self.iterations : tuple
            Running collection of iterations through method.

        self.approximations : tuple
            Finally evaluated solution.

        self.errors : tuple
            Aggregate of yielded norms.

        Warnings
        --------
        Prints to console whether or not a solution was found within the specified tolerance with the supplied, initial guess.

        See Also
        --------
        norms.l_infinity() : Will find the l_infinity norm between x0 and xi.

        norms.l_two() : Will find the l_2 norm between x0 and xi.

        Notes
        -----
        gauss_seidel():
            [x]_(k) = ( (D - L)^(-1) * U ) * [x]_(k - 1) + ( (D - L)^(-1) )*[b]
        """
        A, x0, b, tol, N = self.A, self.x0, self.b, self.tol, self.max_iter
        norm_type, norm = self.norm_type, tol*10
        # A = np.zeros((N, N))
        # np.fill_diagonal(A, ai)
        # A = A + np.diagflat(bi, 1)
        # A = A + np.diagflat(ci, -1)
        # x0 = np.zeros(N)
        # b = np.array(di)
        # A1, A2 = np.zeros((n, n)), np.zeros((n, n))
        # np.fill_diagonal(A1, np.diagonal(A))
        # A1 = A1 - np.tril(A, k=-1)
        # i = 0
        # while i < n:
        # 	j = 0
        # 	while j <= i:
        # 		a1ij = A1[i][j]
        # 		if a1ij != 0:
        # 			A2[i][j] = 1/a1ij
        # 		j += 1
        # 	i += 1
        # self.T = np.matmul(A2, np.triu(A, k=1))
        # self.c = np.matmul(A2, b)
        k, n, approximations, errors = 1, len(x0), [x0.reshape(1, len(x0))], [norm]
        while errors[-1] > tol and k <= N:
            i, xi = 0, np.zeros_like(x0)
            while i < n:
                j, y1, y2 = 0, 0., 0.
                while j <= i-1:
                    y1 += A[i][j]*xi[j]
                    j += 1
                j = i + 1
                while j < n:
                    y2 += A[i][j]*x0[j]
                    j += 1
                xi[i] = (-y1 - y2 + b[i])/A[i][i]
                i += 1
            # xi = self.__find_xk(x0)
            if norm_type == "l_infinity":
                norm = nm.norms(xi, x0).l_infinity()
            elif norm_type == "l_two":
                norm = nm.norms(xi, x0).l_two()
            approximations.append(xi.reshape(1, len(xi))[0])
            errors.append(norm)
            x0 = xi
            k += 1
        if k <= N: print("Congratulations! Solution found!")
        else: print("Warning! Solution could not be found with initial guess or tolerance.")
        # m, n = len(approximations[0]), len(approximations)
        # j, x = 0, np.zeros((m,n))
        # while j < n:
        # 	i = 0
        # 	while i < m:
        # 		x[i][j] = float(approximations[j][i])
        # 		i += 1
        # 	j += 1
        self.iterations = np.array(range(k))
        self.approximations = np.array(approximations, dtype=object)
        self.errors = np.array(errors)
        return pd.DataFrame(data={"Iterations": self.iterations, "Approximations": self.approximations, "Error": self.errors})

    def jacobi(self):
        """Given A*x = b, use `self.norm_type` to find x via the Jacobi Method.

        Returns
        -------
        pandas.DataFrame : dataframe
            Summarized dataframe from iterations.

        Yields
        -------
        self.iterations : tuple
            Collection of iterations through method.

        self.approximations : tuple
            Collection of approximated, iterative solutions.

        self.errors : tuple
            Collection of yielded norms.

        Warnings
        --------
        Prints to console whether or not a solution was found within the specified tolerance with the supplied, initial guess.

        See Also
        --------
        norms.l_infinity() : Will find the l_infinity norm between x0 and xi.

        norms.l_two() : Will find the l_2 norm between x0 and xi.

        Notes
        -----
        jacobi():
        [x]_(k) = ( D^(-1)*(L + U) ) * [x]_(k - 1) + ( D^(-1) ) * [b]
        """
        A, x0, b, tol, N = self.A, self.x0, self.b, self.tol, self.max_iter
        norm_type, norm = self.norm_type, tol*10
        k, n, approximations, errors = 1, len(x0), [x0], [norm]
        while errors[-1] > tol and k <= N:
            i, xi = 0, np.zeros_like(x0)
            while i < n:
                j, y = 0, 0.
                while j < n:
                    if j != i:
                        y += A[i][j]*x0[j]
                    j += 1
                xi[i] = (-y + b[i])/A[i][i]
                i += 1
            if norm_type == "l_infinity":
                norm = nm.norms(xi, x0).l_infinity()
            elif norm_type == "l_two":
                norm = nm.norms(xi, x0).l_two()
            approximations.append(xi)
            errors.append(norm)
            x0 = xi
            k += 1
        if k <= N: print("Congratulations! Solution found!")
        else: print("Warning! Solution could not be found with initial guess or tolerance.")
        # m, n = len(approximations[0]), len(approximations)
        # X_matrix, j = np.zeros((m,n)), 0
        # while j < n:
        # 	i = 0
        # 	while i < m:
        # 		X_matrix[i][j] = float(approximations[j][i])
        # 		i += 1
        # 	j += 1
        self.iterations = np.array(range(k))
        self.approximations = np.array(approximations)
        self.errors = np.array(errors)
        return pd.DataFrame(data={"Iterations": self.iterations, "Approximations": self.approximations, "Error": self.errors})

    # def newton_raphson(self, functions, symbols, x0, powers, max_iter=100, norm_type=None):
    # 	"""Given an array of functions, symbols, and initial guesses, employ the Newton-Raphson Method to find solution within tolerance.

    # 	Root-finding problem: f(x) = 0. 

    # 	!!! Use lowest k !!!

    # 	Parameters
    # 	----------

    # 	functions

    # 	symbols

    # 	x0

    # 	powers

    # 	max_iter

    # 	nomr_type

    # 	p0 : float
    # 		Initial guess.

    # 	k : float, optional
    # 		Absolute maximum slope of function.

    # 	Yields
    # 	-------
    # 	self.iterations : tuple
    # 		Collection of iterations through method.

    # 	self.approximations : tuple
    # 		Collection of approximated, iterative solutions.

    # 	self.errors : tuple
    # 		Collection of yielded norms.

    # 	Raises
    # 	------
    # 	__bad_iter : string
    # 	If input for desired iterations was assigned not an integer.

    # 	__must_be_expression : string
    # 		If input `f` was of array, list, tuple, etcetera...

    # 	Warns
    # 	-----
    # 	__solution_found : string
    # 		Inform user that solution was indeed found.

    # 	__solution_not_found : string
    # 		If initial guess or tolerance were badly defined.

    # 	Notes
    # 	-----
    # 	f'(x) != 0.

    # 	Not root-bracketed.

    # 	Initial guess must be close to real solution; else, will converge to different root or oscillate (if symmetric).

    # 	Check that |g'(x)| <= (leading coefficient of g'(x)) for all x in [a, b].

    # 	Technique based on first Taylor polynomial expansion of `f` about `p0` and evaluated at x = p. |p - p0| is assumed small; therefore, 2nd order Taylor term, the error, is small.

    # 	Newton-Raphson has quickest convergence rate.

    # 	This method can be viewed as fixed-point iteration.

    # 	Theorem:
    # 	1) Existence of a fixed-point:
    # 		If g in C[a, b] and g(x) in C[a, b] for all x in [a, b], then function, g has a fixed point in [a, b].

    # 	2) Uniqueness of a fixed point:
    # 		If g'(x) exists on [a, b] and a positive constant, `k` < 1 exist with {|g'(x)| <= k  |  x in (a, b)}, then there is exactly one fixed-point, `p` in [a, b].

    # 	Converges by O(linear) if g'(p) != 0, and O(quadratic) if g'(p) = 0 and g''(p) < M, where M = g''(xi) that is the error function.

    # 	Examples 
    # 	--------
    # 	If  g(x) = x**2 - 2

    # 	Then	p = g(p) = p**2 - 2

    # 	=>  p**2 - p - 2 = 0
    # 	"""
    # 	def jacobian(g, sym_x, x):
    # 		n = len(x)
    # 		jacMatrix = np.zeros((n, n))
    # 		for i in range(0, n):
    # 			for j in range(0, n):
    # 				J_ij = sp.diff(g[i](*sym_x), sym_x[j])
    # 				temp = sp.lambdify(sym_x, J_ij)(*x)
    # 				if isinstance(temp, type(np.array([1]))): temp = temp[0]
    # 				jacMatrix[i][j] = temp
    # 		return
    # 	norm_type = self.norm_type
    # 	functions, x0, b, norm = self.A, self.x0, self.b, self.tol*10
    # 	xi = np.zeros_like(x0)
    # 	X0, error = [], []
    # 	k, n = 0, len(x0)
    # 	for symbol in symbols:
    # 		if isinstance(symbol, (str, type(sp.Symbol("x")))): continue
    # 		else: raise TypeError(f"All elements of `symbols` must be of type string or symbol: {symbol} was neither.")
    # 	if max_iter <= 0 or not isinstance(max_iter, (int, float)): ValueError(f"ERROR! Maximum iterations, N must be an integer greater than zero. {max_iter} was given and not understood.")
    # 	if norm_type == None:
    # 		tol = []
    # 		for p in powers: tol.append(10**p)
    # 	else: tol = 10**powers
    # 	functions, x0 = np.reshape(functions, (1, n))[0], np.reshape(x0, (n, 1))
    # 	X0.append(x0)
    # 	error.append(tol)
    # 	for k in range(1, max_iter):
    # 		J = jacobian(functions, symbols, x0)
    # 		xk, g = np.zeros_like(x0), np.zeros_like(x0)
    # 		for i in range(0, n): 
    # 			g[i] = sp.lambdify(symbols, functions[i](*symbols))(*x0)
    # 		y0 = np.linalg.solve(J, -g)
    # 		xk = x0 + y0
    # 		if norm_type == "l_two":
    # 			boolean = []
    # 			for i in range(0, n-1):
    # 				if abs(xk[i] - x0[i])[0] <= tol[i]: boolean.append(1)
    # 				else: boolean.append(0)
    # 			x0 = xk
    # 			if sum(boolean) < n: continue
    # 			else: break
    # 		elif norm_type == "l_infinity":
    # 			norm = norms.l_infinity(xk, x0)
    # 			error.append(norm)
    # 			X0.append(xk)
    # 			tol_exit = 0
    # 			for tl in tol:
    # 				if norm <= tl: tol_exit += 0
    # 				else: tol_exit += 1
    # 			if tol_exit == 0:
    # 				self.iterations = np.array(range(k))
    # 				self.approximations = np.array(X0)
    # 				self.errors = np.array(error)
    # 				return pd.DataFrame(data={"Iterations": self.iterations, "Approximations": self.approximations, "Error": self.errors})
    # 			else: x0 = xk
    # 		else: raise ValueError("ERROR! Desired norm type was not understood. Please choose 'l_infinity' or 'l_two'.")
    # 	return x0

    def successive_relaxation(self, omega=None):
        """Given A*x = b, use `self.norm_type` to find vector, x via the Successive Relaxtion Method. Is Successive Over-Relaxation if omega > 1, Successive Under-Relaxation if omega < 1, and is Gauss-Seidel if omega = 1.

        Parameters
        ----------
        omega : None or float, optional
            Relaxation parameter.

        Returns
        -------
        pandas.DataFrame : dataframe
            Summarized dataframe from iterations.

        Yields
        -------
        self.iterations : tuple
            Collection of iterations through method.

        self.approximations : tuple
            Collection of approximated, iterative solutions.

        self.errors : tuple
            Collection of yielded norms.

        Warnings
        --------
        Prints to console optimal choice of omega, regardless of assignment, and whether or not a solution was found within the specified tolerance with the supplied, initial guess.

        See Also
        --------
        norms.l_infinity() : Will find the l_infinity norm between x0 and xi.

        norms.l_two() : Will find the l_2 norm between x0 and xi.

        find_omega() : Will analyze system of equation to find an optimal omega, if possible, and inform user.

        gauss_seidel() : Technique is Gauss-Seidel's modified by omega.

        Notes
        -----
        gauss_seidel():
            [x]_(k) = ( (D - L)^(-1) * U ) * [x]_(k - 1) + ( (D - L)^(-1) )*[b]

        successive_relaxation():
            [x]_(k) = ( (D - wL)^(-1) * ((1 - w)*D + w*U) ) * [x]_(k - 1) + w*( (D - w*L)^(-1) )*[b]

        omega will be analyzed independent of assigned value which will be used if not specified in assignment.
        """
        if omega == None:
            try: w = self.user_omega
            except AttributeError:
                try: w = self.best_omega
                except AttributeError:
                    # w = super().find_omega(A, x0)
                    w = self.find_omega()
                    print(f"Warning! Omega was not given; therefore, I attempted to choose one, {w}.")
                else: print(f"Warning! Using `self.best_omega` = {w}.")
            else: print(f"Warning! Using `self.user_omega` = {w}.")
            if w <= 0: raise ValueError("Either a positive omega was not given, or I could not choose one.")
        elif omega != None and isinstance(omega, (int, float)):
            # omega = find_omega(A, x0, w)
            w = self.find_omega(omega=omega)
            print(f"Warning! omega = {omega} given. Which is not optimum: {w}")
            w = omega
        else: raise ValueError(f"ERROR! Either a positive omega was not given, or I could not choose one.")
        A, x0, b, tol, N = self.A, self.x0, self.b, self.tol, self.max_iter
        norm_type, norm = self.norm_type, tol*10
        k, n, approximations, errors = 0, len(x0), [x0], [norm]
        while norm > tol and k <= N:
            i, xi = 0, np.zeros_like(x0)
            # xgs = super().gauss_seidel(x0)
            xgs = self.gauss_seidel()["Approximations"].values[-1]
            while i < n:
                xi[i] = (1 - w)*x0[i] + w*xgs[i]
                i += 1
            if norm_type == "l_infinity":
                norm = nm.norms(xi, x0).l_infinity()
            elif norm_type == "l_two":
                norm = nm.norms(xi, x0).l_two()
            approximations.append(xi)
            errors.append(norm)
            x0 = xi
            k += 1
        if k <= N: print("Congratulations! Solution found!")
        else: print("Warning! Solution could not be found with initial guess or tolerance.")
        # m, n = len(approximations[0]), len(approximations)
        # X_matrix, j = np.zeros((m,n)), 0
        # while j < n:
        # 	i = 0
        # 	while i < m:
        # 		X_matrix[i][j] = float(approximations[j][i])
        # 		i += 1
        # 	j += 1
        self.iterations = np.array(range(k))
        self.approximations = np.array(approximations)
        self.errors = np.array(errors)
        return pd.DataFrame(data={"Iterations": self.iterations, "Approximations": self.approximations, "Error": self.errors})
# --------------------


# A = np.matrix([[4, 1, 1, 0, 1], [1, 3, 1, 1, 0], [1, 1, 5, -1, -1], [0, 1, -1, 4, 0], [1, 0, -1, 0, 4]])
# x0 = np.array([1, 1, 1, 1, 1]).reshape((5, 1))
# b = np.array([6, 6, 6, 6, 6]).reshape((5, 1))
# C = np.diag(np.diag(A))

# system = DirectSolver(A, -6)
# df_cg_pre = system.conjugate_gradient(x0, b, C)
# print(f"Final Iteration = {df_cg_pre['Iterations'].values[-1]}")
# print(f"Final Approximation = {np.array(df_cg_pre['Lambdas'].values[-1]).reshape(1, len(A))[0]}")
# print(f"Final Error = {df_cg_pre['Errors'].values[-1]}")
# fig, (ax1, ax2) = plt.subplots(1, 2)
# for n in range(len(A)):
# 	vector = []
# 	for i in df_cg_pre["Iterations"].values:
# 		vector.append(float(df_cg_pre["Lambdas"].values[i][n]))
# 	ax1.plot(df_cg_pre["Iterations"].values, vector, label=f"{n}")
# ax1.set_xlabel("Iterations")
# ax1.set_ylabel("x")
# ax1.set_title("Vector, x Approximations")
# ax1.legend()
# error = []
# for i in df_cg_pre["Iterations"].values:
# 	error.append(float(df_cg_pre["Error"].values[i]))
# ax2.plot(df_cg_pre["Iterations"].values, error, label=f"Error")
# ax2.set_xlabel("Iterations")
# ax2.set_ylabel("Error")
# ax2.set_title("Residual Error")
# ax2.legend()
# plt.show()

A0_1, B0_1, C0_1, D0_1 = (0, 1), (1, 1), (1, 0), (0, 0) # m
# A1_1, B1_1, C1_1, D1_1 = A0_1 + (-0.003, 0.0025), B0_1 + (-0.005, 0.0035), C0_1 + (-0.002, 0.001), D0_1 + (0, 0) # m
A1_1, B1_1, C1_1, D1_1 = (-0.003, 0.0025), (-0.005, 0.0035), (-0.002, 0.001), (0, 0) # m
theta_1 = np.radians(30) # rad
sym_c_1 = [sp.Symbol("c1"), sp.Symbol("c2"), sp.Symbol("c3"), sp.Symbol("c4")]
sym_d_1 = [sp.Symbol("d1"), sp.Symbol("d2"), sp.Symbol("d3"), sp.Symbol("d4")]
u_1 = lambda c, x, y: c[0] + c[1]*x + c[2]*y + c[3]*x*y
v_1 = lambda d, x, y: d[0] + d[1]*x + d[2]*y + d[3]*x*y
sym_xy_1 = sym_x_1, sym_y_1 = sp.Symbol("x"), sp.Symbol("y")
sym_u_1 = sp.expand(u_1(sym_c_1, *sym_xy_1))
sym_v_1 = sp.expand(v_1(sym_d_1, *sym_xy_1))

print(sym_u_1, sym_v_1, sep="\n")

Auv_1 = np.array([\
    # at A
    [1, A0_1[0], A0_1[1], A0_1[0]*A0_1[1]], \
    # at B
    [1, B0_1[0], B0_1[1], B0_1[0]*B0_1[1]], \
    # at C
    [1, C0_1[0], C0_1[1], C0_1[0]*C0_1[1]], \
    # at D
    [1, D0_1[0], D0_1[1], D0_1[0]*D0_1[1]], \
])
uv_sys_1 = DirectSolver(Auv_1, -6, max_iter=len(Auv_1))

bu_1 = np.array([A1_1[0], B1_1[0], C1_1[0], D1_1[0]]).reshape((len(Auv_1), 1))
# x0u_1 = (np.array([1])*sym_c_1).reshape(len(Auv_1), 1)
x0u_1 = np.ones_like(bu_1)
# print(x0u_1)
# c_1 = uv_sys_1.conjugate_gradient(x0u_1, bu_1)["Lambdas"].values[-1]
c_1 = np.linalg.lstsq(Auv_1, bu_1)[0].reshape(1, len(x0u_1))[0]
# print(uv_sys_1.conjugate_gradient(x0u_1, bu_1)["Errors"].values)
# u_sys_1 = MultiVariableIteration(Auv_1, x0u_1, bu_1)
# c_1 = u_sys_1.gauss_seidel()["Approximations"].values[-1]
print(c_1)

bv_1 = np.array([A1_1[1], B1_1[1], C1_1[1], D1_1[1]]).reshape((len(Auv_1), 1))
x0v_1 = np.ones_like(bv_1)
# d_1 = uv_sys_1.conjugate_gradient(x0v_1, bv_1)["Lambdas"].values[-1]
d_1 = np.linalg.lstsq(Auv_1, bv_1)[0].reshape(1, len(x0v_1))[0]
print(d_1)

# build string function from constants
f_1 = lambda sym_function, sym_variables, constants: sp.lambdify(sym_xy_1, sp.lambdify(sym_variables, sym_function)(*constants))
u_1 = lambda point: f_1(sym_u_1, (sym_c_1), c_1)(*point)
sym_u_1 = sp.expand(u_1(sym_xy_1))
v_1 = lambda point: f_1(sym_v_1, (sym_d_1), d_1)(*point)
sym_v_1 = sp.expand(v_1(sym_xy_1))

print(sym_u_1, sym_v_1, sep="\n")

# determine form of derivative
df_1 = lambda sym_function, sym_variable, point: sp.lambdify(sym_xy_1, sp.diff(sym_function, sym_variable))(*point)
epsilon_1 = lambda point: np.array([\
    [df_1(sym_u_1, sym_x_1, point), df_1(sym_u_1, sym_y_1, point) + df_1(sym_v_1, sym_x_1, point)], \
    [df_1(sym_u_1, sym_y_1, point) + df_1(sym_v_1, sym_x_1, point), df_1(sym_v_1, sym_y_1, point)], \
])

epsA_1 = epsilon_1(A0_1)
epsB_1 = epsilon_1(B0_1)
epsC_1 = epsilon_1(C0_1)
epsD_1 = epsilon_1(D0_1)

print(epsA_1, epsB_1, epsC_1, epsD_1, sep="\n")